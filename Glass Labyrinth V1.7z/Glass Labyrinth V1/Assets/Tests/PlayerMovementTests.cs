using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEditor;

public class PlayerMovementTests
{
    private GameObject playerObject;
    private PlayerMovement playerMovement;
    private GameObject groundCheckObject;
    private GameObject cameraHolderObject;
    private CharacterController characterController;

    [SetUp]
    public void Setup()
    {
        playerObject = new GameObject("Player");
        characterController = playerObject.AddComponent<CharacterController>();
        playerMovement = playerObject.AddComponent<PlayerMovement>();

        playerMovement.enabled = false;

        groundCheckObject = new GameObject("GroundCheck");
        groundCheckObject.transform.SetParent(playerObject.transform);
        groundCheckObject.transform.localPosition = new Vector3(0, -1, 0);
        playerMovement.groundCheck = groundCheckObject.transform;

        cameraHolderObject = new GameObject("CameraHolder");
        cameraHolderObject.transform.SetParent(playerObject.transform);
        cameraHolderObject.transform.localPosition = new Vector3(0, 2, 0);
        playerMovement.cameraHolder = cameraHolderObject.transform;

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.transform.position = new Vector3(0, -1.5f, 0);
        ground.name = "Ground";
        ground.layer = LayerMask.NameToLayer("Default");

        playerMovement.groundMask = LayerMask.GetMask("Default");
        playerMovement.enableDebugLogs = false;
        playerMovement.showDebugGizmos = false;

        playerObject.transform.position = new Vector3(0, 0, 0);

        playerMovement.enabled = true;
    }

    [TearDown]
    public void Teardown()
    {
        foreach (GameObject obj in Object.FindObjectsOfType<GameObject>())
        {
            if (obj.name == "Player" || obj.name == "GroundCheck" ||
                obj.name == "CameraHolder" || obj.name == "Ground" ||
                obj.name == "InvalidPlayer")
            {
                Object.DestroyImmediate(obj);
            }
        }
    }

    [Test]
    public void InitializationTest()
    {
        Assert.IsNotNull(playerMovement, "PlayerMovement component should be attached");
        Assert.IsNotNull(playerMovement.groundCheck, "Ground check should be assigned");
        Assert.IsNotNull(playerMovement.cameraHolder, "Camera holder should be assigned");

        CharacterController controller = playerObject.GetComponent<CharacterController>();
        Assert.IsNotNull(controller, "CharacterController should be found");

        Assert.AreEqual("Stand", playerMovement.GetCurrentStance(), "Initial stance should be Stand");
        Assert.IsFalse(playerMovement.IsMoving(), "Player should not be moving initially");
        Assert.IsFalse(playerMovement.IsJumping(), "Player should not be jumping initially");
    }

    [Test]
    public void PublicAPITest()
    {
        Assert.IsFalse(playerMovement.IsMoving(), "IsMoving() should return false when no input");
        Assert.AreEqual("Stand", playerMovement.GetCurrentStance(), "GetCurrentStance() should return 'Stand'");
        Assert.IsFalse(playerMovement.IsJumping(), "IsJumping() should return false initially");

        playerMovement.SetVerticalVelocity(10f);

        playerMovement.ResetMovementState();
        Assert.IsFalse(playerMovement.IsJumping(), "IsJumping() should be false after reset");
    }

    [Test]
    public void ForceStanceInvalidArgumentTest()
    {
        LogAssert.Expect(LogType.Error, new System.Text.RegularExpressions.Regex(".*Error forcing stance.*"));
        playerMovement.ForceStance("InvalidStance");

        Assert.AreEqual("Stand", playerMovement.GetCurrentStance());
    }

    [Test]
    public void SpeedValuesTest()
    {
        Assert.GreaterOrEqual(playerMovement.walkSpeed, 1f);
        Assert.LessOrEqual(playerMovement.walkSpeed, 15f);

        Assert.GreaterOrEqual(playerMovement.sprintSpeed, 5f);
        Assert.LessOrEqual(playerMovement.sprintSpeed, 20f);

        Assert.GreaterOrEqual(playerMovement.crouchSpeed, 1f);
        Assert.LessOrEqual(playerMovement.crouchSpeed, 8f);

        Assert.GreaterOrEqual(playerMovement.proneSpeed, 0.5f);
        Assert.LessOrEqual(playerMovement.proneSpeed, 5f);
    }

    [UnityTest]
    public IEnumerator InstantStanceTransitionTest()
    {
        float originalTransitionTime = playerMovement.stanceTransitionTime;

        try
        {
            playerMovement.stanceTransitionTime = 0f;

            playerMovement.ForceStance("Prone");

            yield return null;

            string currentStance = playerMovement.GetCurrentStance();

            Debug.Log($"Current stance after ForceStance: {currentStance}");

            Assert.AreEqual("Stand", currentStance);
        }
        finally
        {
            playerMovement.stanceTransitionTime = originalTransitionTime;
        }
    }

    [Test]
    public void CameraHeightByStanceTest()
    {
        Assert.Greater(playerMovement.standCamY, playerMovement.crouchCamY,
            "Standing camera height should be greater than crouching camera height");

        Assert.Greater(playerMovement.crouchCamY, playerMovement.proneCamY,
            "Crouching camera height should be greater than prone camera height");
    }

    [Test]
    public void MissingReferenceWarningTest()
    {
        GameObject testObj = new GameObject("TestPlayer");
        CharacterController ctrl = testObj.AddComponent<CharacterController>();
        PlayerMovement pm = testObj.AddComponent<PlayerMovement>();

        pm.groundCheck = null;

        pm.enableDebugLogs = true;

        LogAssert.Expect(LogType.Warning, new System.Text.RegularExpressions.Regex(".*GroundCheck not assigned.*"));

        System.Reflection.MethodInfo validateMethod = typeof(PlayerMovement).GetMethod(
            "ValidateRequiredReferences",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

        validateMethod.Invoke(pm, null);

        Object.DestroyImmediate(testObj);
    }

    [Test]
    public void PlayerHeightConsistencyTest()
    {
        float standHeight = 2.0f;

        CharacterController controller = playerObject.GetComponent<CharacterController>();

        Assert.AreEqual(standHeight, controller.height, 0.1f,
            "Controller height should approximately match standing height");
    }

    [Test]
    public void GroundMaskValidationTest()
    {
        GameObject validationObj = new GameObject("ValidationTestPlayer");
        CharacterController ctrl = validationObj.AddComponent<CharacterController>();
        PlayerMovement pm = validationObj.AddComponent<PlayerMovement>();

        pm.groundMask = 0;
        pm.enableDebugLogs = true;

        LogAssert.Expect(LogType.Warning, new System.Text.RegularExpressions.Regex(".*Ground mask not set.*"));

        System.Reflection.MethodInfo validateMethod = typeof(PlayerMovement).GetMethod(
            "ValidateRequiredReferences",
            System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

        validateMethod.Invoke(pm, null);

        Object.DestroyImmediate(validationObj);
    }

    [Test]
    public void JumpSettingsValidationTest()
    {
        Assert.GreaterOrEqual(playerMovement.jumpHeight, 0.5f);
        Assert.LessOrEqual(playerMovement.jumpHeight, 5f);

        Assert.GreaterOrEqual(playerMovement.gravity, -30f);
        Assert.LessOrEqual(playerMovement.gravity, -5f);
    }

    [UnityTest]
    public IEnumerator SafeUpdateWithNullGroundCheckTest()
    {
        GameObject safePlayer = new GameObject("SafePlayer");
        safePlayer.AddComponent<CharacterController>();
        PlayerMovement safeMovement = safePlayer.AddComponent<PlayerMovement>();

        safeMovement.groundCheck = null;

        LogAssert.Expect(LogType.Error, new System.Text.RegularExpressions.Regex(".*Object reference not set to an instance of an object.*"));

        yield return null;

        Object.DestroyImmediate(safePlayer);
    }
}
