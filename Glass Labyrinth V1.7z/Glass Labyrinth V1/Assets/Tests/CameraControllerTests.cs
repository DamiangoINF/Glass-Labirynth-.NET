using System;
using System.Collections;
using System.Reflection;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

public class CameraControllerTests
{
    private GameObject camObject;
    private CameraController cameraController;
    private GameObject cameraHolderObject;
    private Transform cameraHolderTransform;
    private Transform groundCheckTransform;
    private MockPlayerMovement mockPlayerMovement;

    private const BindingFlags privateInstanceFlags = BindingFlags.NonPublic | BindingFlags.Instance;
    private FieldInfo xRotationField;
    private FieldInfo bobTimerField;
    private FieldInfo currentMouseDeltaField;
    private FieldInfo defaultYPosField;
    private FieldInfo isInitializedField;

    public class MockPlayerMovement : PlayerMovement
    {
        private bool isGrounded = true;
        private bool isMoving = true;
        private string currentStance = "Stand";

        public override bool IsGrounded() => isGrounded;
        public override bool IsMoving() => isMoving;
        public override string GetCurrentStance() => currentStance;

        public void SetGroundedState(bool state)
        {
            isGrounded = state;
        }

        public void SetMovingState(bool state)
        {
            isMoving = state;
        }

        public void SetCurrentStance(string stance)
        {
            currentStance = stance;
        }
    }

    [UnitySetUp]
    public IEnumerator SetUp()
    {
        LogAssert.ignoreFailingMessages = true;

        camObject = new GameObject("Camera");
        cameraController = camObject.AddComponent<CameraController>();

        cameraHolderObject = new GameObject("CameraHolder");
        cameraHolderTransform = cameraHolderObject.transform;
        cameraHolderTransform.SetParent(camObject.transform);
        cameraController.cameraHolder = cameraHolderTransform;

        mockPlayerMovement = camObject.AddComponent<MockPlayerMovement>();
        var controller = camObject.AddComponent<CharacterController>();

        var groundCheckObject = new GameObject("GroundCheck");
        groundCheckTransform = groundCheckObject.transform;
        groundCheckTransform.SetParent(camObject.transform);
        mockPlayerMovement.groundCheck = groundCheckTransform;
        mockPlayerMovement.cameraHolder = cameraHolderTransform;
        mockPlayerMovement.groundMask = LayerMask.GetMask("Default");

        cameraController.playerMovement = mockPlayerMovement;

        xRotationField = typeof(CameraController).GetField("xRotation", privateInstanceFlags);
        bobTimerField = typeof(CameraController).GetField("bobTimer", privateInstanceFlags);
        currentMouseDeltaField = typeof(CameraController).GetField("currentMouseDelta", privateInstanceFlags);
        defaultYPosField = typeof(CameraController).GetField("defaultYPos", privateInstanceFlags);
        isInitializedField = typeof(CameraController).GetField("isInitialized", privateInstanceFlags);

        cameraController.mouseSensitivity = 200f;
        cameraController.dragSmoothTime = 0.2f;
        cameraController.bobSpeed = 10f;
        cameraController.bobAmount = 0.05f;
        cameraController.returnToDefaultSpeed = 6f;
        cameraController.minVerticalAngle = -90f;
        cameraController.maxVerticalAngle = 90f;

        yield return null;
    }

    [UnityTearDown]
    public IEnumerator TearDown()
    {
        if (cameraController != null)
        {
            UnityEngine.Object.Destroy(cameraController);
        }

        if (camObject != null)
        {
            UnityEngine.Object.Destroy(camObject);
        }

        if (cameraHolderObject != null)
        {
            UnityEngine.Object.Destroy(cameraHolderObject);
        }

        yield return null;
    }

    #region Property Validation Tests

    [Test]
    public void MouseSensitivity_IsPositive()
    {
        float sensitivity = cameraController.mouseSensitivity;

        Assert.Greater(sensitivity, 0f, "Mouse sensitivity should be greater than zero");
    }

    [Test]
    public void MouseSensitivity_IsInAcceptableRange()
    {
        float sensitivity = cameraController.mouseSensitivity;

        Assert.That(sensitivity, Is.InRange(50f, 500f), "Mouse sensitivity should be within 50-500 range");
    }

    [Test]
    public void DragSmoothTime_IsNonNegative()
    {
        float smoothTime = cameraController.dragSmoothTime;

        Assert.GreaterOrEqual(smoothTime, 0f, "Drag smooth time should be non-negative");
    }

    [Test]
    public void DragSmoothTime_IsInAcceptableRange()
    {
        float smoothTime = cameraController.dragSmoothTime;

        Assert.That(smoothTime, Is.InRange(0.1f, 1f), "Drag smooth time should be within 0.1-1.0 range");
    }

    [Test]
    public void BobSpeed_IsPositive()
    {
        float bobSpeed = cameraController.bobSpeed;

        Assert.Greater(bobSpeed, 0f, "Bob speed should be greater than zero");
    }

    [Test]
    public void BobSpeed_IsInAcceptableRange()
    {
        float bobSpeed = cameraController.bobSpeed;

        Assert.That(bobSpeed, Is.InRange(1f, 20f), "Bob speed should be within 1-20 range");
    }

    [Test]
    public void BobAmount_IsSmallPositive()
    {
        float bobAmount = cameraController.bobAmount;

        Assert.That(bobAmount, Is.InRange(0.01f, 0.2f), "Bob amount should be within 0.01-0.2 range");
    }

    [Test]
    public void ReturnToDefaultSpeed_IsInAcceptableRange()
    {
        float returnSpeed = cameraController.returnToDefaultSpeed;

        Assert.That(returnSpeed, Is.InRange(1f, 12f), "Return to default speed should be within 1-12 range");
    }

    [Test]
    public void VerticalAngleLimits_AreValid()
    {
        float minAngle = cameraController.minVerticalAngle;
        float maxAngle = cameraController.maxVerticalAngle;

        Assert.Less(minAngle, maxAngle, "Min vertical angle should be less than max vertical angle");
        Assert.That(minAngle, Is.InRange(-90f, 0f), "Min vertical angle should be within -90 to 0 range");
        Assert.That(maxAngle, Is.InRange(0f, 90f), "Max vertical angle should be within 0 to 90 range");
    }

    #endregion

    #region Reference Validation Tests

    [Test]
    public void CameraHolder_IsAssigned()
    {
        Assert.IsNotNull(cameraController.cameraHolder, "Camera holder should not be null");
    }

    [Test]
    public void PlayerMovement_IsAssigned()
    {
        Assert.IsNotNull(cameraController.playerMovement, "Player movement should not be null");
    }

    #endregion

    #region Initialization Tests

    [UnityTest]
    public IEnumerator Cursor_IsLocked_OnStart()
    {
        Cursor.lockState = CursorLockMode.None;

        cameraController.SendMessage("Start");

        yield return null;

        Assert.AreEqual(CursorLockMode.Locked, Cursor.lockState, "Cursor should be locked after Start");
    }

    [UnityTest]
    public IEnumerator IsInitialized_IsTrue_AfterStart()
    {
        isInitializedField.SetValue(cameraController, false);

        cameraController.SendMessage("Start");

        yield return null;

        bool isInitialized = (bool)isInitializedField.GetValue(cameraController);
        Assert.IsTrue(isInitialized, "isInitialized flag should be true after Start");
    }

    [UnityTest]
    public IEnumerator DefaultYPos_IsSet_AfterStart()
    {
        float originalY = camObject.transform.localPosition.y;
        defaultYPosField.SetValue(cameraController, 0f);

        cameraController.SendMessage("Start");

        yield return null;

        float defaultYPos = (float)defaultYPosField.GetValue(cameraController);
        Assert.AreEqual(originalY, defaultYPos, "Default Y position should match the transform's Y position");
    }

    [Test]
    public void DefaultXRotation_IsZero()
    {
        float xRotation = (float)xRotationField.GetValue(cameraController);

        Assert.AreEqual(0f, xRotation, "Default X rotation should be zero");
    }

    [Test]
    public void DefaultMouseDelta_IsZero()
    {
        Vector2 mouseDelta = (Vector2)currentMouseDeltaField.GetValue(cameraController);

        Assert.AreEqual(Vector2.zero, mouseDelta, "Default mouse delta should be zero");
    }

    #endregion

    #region Mouse Look Tests

    [Test]
    public void SetMouseSensitivity_UpdatesValue_WhenInValidRange()
    {
        float newSensitivity = 300f;

        bool result = cameraController.SetMouseSensitivity(newSensitivity);

        Assert.IsTrue(result, "SetMouseSensitivity should return true for valid input");
        Assert.AreEqual(newSensitivity, cameraController.mouseSensitivity, "Mouse sensitivity should be updated");
    }

    [Test]
    public void SetMouseSensitivity_ReturnsFalse_WhenOutOfRange()
    {
        float originalSensitivity = cameraController.mouseSensitivity;
        float invalidSensitivity = 1000f;

        bool result = cameraController.SetMouseSensitivity(invalidSensitivity);

        Assert.IsFalse(result, "SetMouseSensitivity should return false for invalid input");
        Assert.AreEqual(originalSensitivity, cameraController.mouseSensitivity, "Mouse sensitivity should not change");
    }

    [UnityTest]
    public IEnumerator TestMouseInput_ChangesRotation()
    {
        float initialXRotation = (float)xRotationField.GetValue(cameraController);
        Quaternion initialYRotation = cameraController.cameraHolder.rotation;

        cameraController.TestMouseInput(1f, 1f);

        yield return null;

        float currentXRotation = (float)xRotationField.GetValue(cameraController);
        Quaternion currentYRotation = cameraController.cameraHolder.rotation;

        Assert.AreNotEqual(initialXRotation, currentXRotation, "X rotation should change after mouse input");
        Assert.AreNotEqual(initialYRotation, currentYRotation, "Y rotation should change after mouse input");
    }

    [Test]
    public void VerticalRotation_IsClampedWithinLimits()
    {
        xRotationField.SetValue(cameraController, -100f);

        cameraController.TestMouseInput(0f, 0f);
        float clampedValue = (float)xRotationField.GetValue(cameraController);

        Assert.AreEqual(-90f, clampedValue, "X rotation should be clamped to minimum value");

        xRotationField.SetValue(cameraController, 100f);

        cameraController.TestMouseInput(0f, 0f);
        clampedValue = (float)xRotationField.GetValue(cameraController);

        Assert.AreEqual(90f, clampedValue, "X rotation should be clamped to maximum value");
    }

    [Test]
    public void GetCurrentPitch_ReturnsXRotation()
    {
        float expectedPitch = 30f;
        xRotationField.SetValue(cameraController, expectedPitch);

        float actualPitch = cameraController.GetCurrentPitch();

        Assert.AreEqual(expectedPitch, actualPitch, "GetCurrentPitch should return the current X rotation");
    }

    #endregion

    #region Headbob Tests

    [UnityTest]
    public IEnumerator Headbob_IsActive_WhenPlayerIsGroundedAndMoving()
    {
        mockPlayerMovement.SetGroundedState(true);
        mockPlayerMovement.SetMovingState(true);
        float initialBobTimer = (float)bobTimerField.GetValue(cameraController);
        cameraController.SendMessage("Start");

        cameraController.SendMessage("Update");

        yield return null;

        float updatedBobTimer = (float)bobTimerField.GetValue(cameraController);
        Assert.AreNotEqual(initialBobTimer, updatedBobTimer, "Bob timer should be updated when player is grounded and moving");
    }

    [UnityTest]
    public IEnumerator Headbob_IsInactive_WhenPlayerIsNotGrounded()
    {
        mockPlayerMovement.SetGroundedState(false);
        mockPlayerMovement.SetMovingState(true);
        bobTimerField.SetValue(cameraController, 1.0f);
        float initialBobTimer = (float)bobTimerField.GetValue(cameraController);
        cameraController.SendMessage("Start");

        cameraController.SendMessage("Update");

        yield return null;

        float updatedBobTimer = (float)bobTimerField.GetValue(cameraController);
        Assert.AreEqual(0f, updatedBobTimer, "Bob timer should be reset to zero when player is not grounded");
    }

    [UnityTest]
    public IEnumerator Headbob_IsInactive_WhenPlayerIsNotMoving()
    {
        mockPlayerMovement.SetGroundedState(true);
        mockPlayerMovement.SetMovingState(false);
        bobTimerField.SetValue(cameraController, 1.0f);
        float initialBobTimer = (float)bobTimerField.GetValue(cameraController);
        cameraController.SendMessage("Start");

        cameraController.SendMessage("Update");

        yield return null;

        float updatedBobTimer = (float)bobTimerField.GetValue(cameraController);
        Assert.AreEqual(0f, updatedBobTimer, "Bob timer should be reset to zero when player is not moving");
    }

    [UnityTest]
    public IEnumerator StanceMultiplier_AffectsHeadbobTimer()
    {
        mockPlayerMovement.SetGroundedState(true);
        mockPlayerMovement.SetMovingState(true);
        mockPlayerMovement.SetCurrentStance("Stand");
        cameraController.SendMessage("Start");
        bobTimerField.SetValue(cameraController, 0f);

        cameraController.SendMessage("Update");
        yield return null;
        float standingIncrement = (float)bobTimerField.GetValue(cameraController);

        bobTimerField.SetValue(cameraController, 0f);
        mockPlayerMovement.SetCurrentStance("Crouch");

        cameraController.SendMessage("Update");
        yield return null;
        float crouchingIncrement = (float)bobTimerField.GetValue(cameraController);

        Assert.Greater(standingIncrement, crouchingIncrement,
            "Headbob timer should increase more rapidly in standing stance than crouching stance");
    }

    #endregion

    #region Reset Camera Tests

    [Test]
    public void ResetCamera_ResetsOrientationAndPosition()
    {
        xRotationField.SetValue(cameraController, 45f);
        bobTimerField.SetValue(cameraController, 3.14f);
        cameraController.cameraHolder.rotation = Quaternion.Euler(0f, 30f, 0f);
        Vector3 originalPosition = camObject.transform.localPosition;

        cameraController.ResetCamera();

        float xRotation = (float)xRotationField.GetValue(cameraController);
        float bobTimer = (float)bobTimerField.GetValue(cameraController);

        Assert.AreEqual(0f, xRotation, "X rotation should be reset to zero");
        Assert.AreEqual(0f, bobTimer, "Bob timer should be reset to zero");
        Assert.AreEqual(Quaternion.identity.eulerAngles, cameraController.transform.localRotation.eulerAngles,
            "Camera local rotation should be reset to identity");
        Assert.AreEqual(Quaternion.identity.eulerAngles, cameraController.cameraHolder.localRotation.eulerAngles,
            "Camera holder local rotation should be reset to identity");
    }

    #endregion

    #region Error Handling Tests

    [Test]
    public void MissingCameraHolder_HandledGracefully()
    {
        cameraController.cameraHolder = null;

        Assert.DoesNotThrow(() => {
            cameraController.TestMouseInput(1f, 1f);
        }, "Camera controller should handle missing camera holder without throwing exception");
    }

    [Test]
    public void MissingPlayerMovement_HandledGracefully()
    {
        cameraController.playerMovement = null;

        Assert.DoesNotThrow(() => {
            cameraController.SendMessage("Update");
        }, "Camera controller should handle missing player movement without throwing exception");
    }

    [Test]
    public void SetCursorState_HandlesExceptions()
    {
        Assert.DoesNotThrow(() => {
            cameraController.SetCursorState(CursorLockMode.Locked);
            cameraController.SetCursorState(CursorLockMode.None);
        }, "Set cursor state should handle cursor state changes without throwing");
    }

    #endregion

    #region Special Case Tests

    [UnityTest]
    public IEnumerator GetStanceMultiplier_HandlesUnknownStance()
    {
        mockPlayerMovement.SetGroundedState(true);
        mockPlayerMovement.SetMovingState(true);
        mockPlayerMovement.SetCurrentStance("InvalidStance");
        cameraController.SendMessage("Start");

        cameraController.SendMessage("Update");

        yield return null;

        Assert.DoesNotThrow(() => {
            cameraController.SendMessage("Update");
        }, "Camera controller should handle unknown stance without throwing");
    }

    [Test]
    public void BobTimer_OverflowPrevention_Works()
    {
        float largeValue = Mathf.PI * 3;
        float expectedValue = largeValue - (Mathf.PI * 2);
        bobTimerField.SetValue(cameraController, largeValue);

        var methodInfo = typeof(CameraController).GetMethod("UpdateBobTimer", BindingFlags.NonPublic | BindingFlags.Instance);

        methodInfo.Invoke(cameraController, new object[] { 1.0f });
        float resultValue = (float)bobTimerField.GetValue(cameraController);

        Assert.That(resultValue, Is.LessThan(Mathf.PI * 2), "Bob timer should be prevented from growing too large");
    }

    #endregion
}
