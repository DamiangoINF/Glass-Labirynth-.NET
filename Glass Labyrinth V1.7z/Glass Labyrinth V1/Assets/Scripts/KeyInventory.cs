using System.Collections.Generic;
using UnityEngine;

public static class KeyInventory
{
    private static HashSet<string> collectedKeys = new HashSet<string>();

    public static void AddKey(string id)
    {
        collectedKeys.Add(id);
    }

    public static bool HasKey(string id)
    {
        return collectedKeys.Contains(id);
    }
}
