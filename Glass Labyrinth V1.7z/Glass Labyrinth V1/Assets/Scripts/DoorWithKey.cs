using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class DoorWithKey : MonoBehaviour, IInteractable
{
    public string requiredKeyID = "DefaultKey";

    private Renderer rend;
    private Color originalColor;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        originalColor = rend.material.color;
    }

    public void Interact()
    {
        if (KeyInventory.HasKey(requiredKeyID))
        {
            Debug.Log("Door opened!");
            Destroy(gameObject);
        }
        else
        {
            Debug.Log("You need a key to open this door.");
        }
    }

    public void Highlight(bool on)
    {
        if (rend == null) return;

        if (on)
        {
            Color highlightedColor = originalColor * 1.25f;
            highlightedColor.a = 1f;
            rend.material.color = highlightedColor;
        }
        else
        {
            rend.material.color = originalColor;
        }
    }
}
