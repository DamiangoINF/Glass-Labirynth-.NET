using System;
using System.Collections;
using UnityEngine;

/// <summary>
/// Controls player movement including walking, sprinting, crouching, prone,
/// jumping, and handling different player stances.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class PlayerMovement : MonoBehaviour
{
    #region Inspector Fields

    [Header("Movement Settings")]
    [Tooltip("Player movement speed when walking")]
    [Range(1f, 15f)]
    public float walkSpeed = 6f;

    [Tooltip("Player movement speed when sprinting")]
    [Range(5f, 20f)]
    public float sprintSpeed = 9f;

    [Tooltip("Player movement speed when crouching")]
    [Range(1f, 8f)]
    public float crouchSpeed = 4f;

    [Tooltip("Player movement speed when prone")]
    [Range(0.5f, 5f)]
    public float proneSpeed = 2f;

    [Tooltip("Height of player jump in units")]
    [Range(0.5f, 5f)]
    public float jumpHeight = 2f;

    [Tooltip("Acceleration due to gravity")]
    [Range(-30f, -5f)]
    public float gravity = -12f;

    [Header("Ground Check")]
    [Tooltip("Transform used to check if player is grounded")]
    public Transform groundCheck;

    [Tooltip("Radius of sphere used for ground detection")]
    [Range(0.1f, 1f)]
    public float groundDistance = 0.5f;

    [Tooltip("Layers that count as ground for the player")]
    public LayerMask groundMask;

    [Header("Camera Settings")]
    [Tooltip("Transform for the player's camera")]
    public Transform cameraHolder;

    [Tooltip("Camera Y position when standing")]
    [Range(1f, 3f)]
    public float standCamY = 2f;

    [Tooltip("Camera Y position when crouching")]
    [Range(0.5f, 2f)]
    public float crouchCamY = 1.2f;

    [Tooltip("Camera Y position when prone")]
    [Range(0.2f, 1f)]
    public float proneCamY = 0.7f;

    [Tooltip("Speed at which camera transitions between stances")]
    [Range(1f, 15f)]
    public float cameraLerpSpeed = 6f;

    [Header("Advanced Settings")]
    [Tooltip("Time required to transition between stances")]
    [Range(0f, 2f)]
    public float stanceTransitionTime = 0.25f;

    [Tooltip("If true, player will automatically stand when jumping")]
    public bool autoStandOnJump = true;

    [Tooltip("If true, sprint can only be activated while moving forward")]
    public bool forwardSprintOnly = true;

    [Tooltip("If true, applies air control limitations")]
    public bool limitAirControl = true;

    [Tooltip("Air control factor (0 = no control, 1 = full control)")]
    [Range(0f, 1f)]
    public float airControlFactor = 0.5f;

    [Tooltip("Speed of ground acceleration")]
    [Range(1f, 50f)]
    public float groundAcceleration = 15f;

    [Tooltip("Input device for controls")]
    public enum InputDevice { KeyboardMouse, Gamepad }
    public InputDevice inputDevice = InputDevice.KeyboardMouse;

    [Header("Key Bindings")]
    [Tooltip("Key used for crouching")]
    public KeyCode crouchKey = KeyCode.C;

    [Tooltip("Key used for going prone")]
    public KeyCode proneKey = KeyCode.Z;

    [Tooltip("Key used for sprinting")]
    public KeyCode sprintKey = KeyCode.LeftShift;

    [Tooltip("Key used for jumping")]
    public KeyCode jumpKey = KeyCode.Space;

    [Header("Debug Settings")]
    [Tooltip("Enable visual debugging")]
    public bool showDebugGizmos = true;

    [Tooltip("Enable console logging")]
    public bool enableDebugLogs = false;

    #endregion

    #region Private Fields

    private CharacterController controller;

    private Vector3 moveDirection = Vector3.zero;
    private Vector3 velocity = Vector3.zero;
    private float currentSpeed = 0f;
    private float targetSpeed = 0f;

    private bool isGrounded = false;
    private bool wasGroundedLastFrame = false;
    private float timeSinceGrounded = 0f;

    private bool isJumping = false;
    private float lastJumpTime = -10f;

    private enum PlayerStance { Stand, Crouch, Prone }
    private PlayerStance currentStance = PlayerStance.Stand;
    private PlayerStance targetStance = PlayerStance.Stand;
    private float stanceTransitionProgress = 1f;
    private bool isTransitioningStance = false;
    private float currentStanceHeight = 2f;
    private Coroutine stanceTransitionCoroutine;

    private Vector2 movementInput = Vector2.zero;
    private bool jumpInput = false;
    private bool sprintInput = false;
    private bool crouchInput = false;
    private bool proneInput = false;

    private const float COYOTE_TIME = 0.15f;
    private const float JUMP_COOLDOWN = 0.25f;
    private const float MIN_GROUND_NORMAL_Y = 0.5f;
    private const float GROUND_CHECK_TOLERANCE = 0.05f;

    #endregion

    #region Unity Lifecycle Methods

    /// <summary>
    /// Initialize components and validate references on start
    /// </summary>
    private void Start()
    {
        try
        {
            controller = GetComponent<CharacterController>();
            if (controller == null)
            {
                throw new MissingComponentException("CharacterController component is missing!");
            }

            ValidateRequiredReferences();

            float startHeight = GetHeightForStance(PlayerStance.Stand);
            currentStanceHeight = startHeight;
            transform.position = new Vector3(transform.position.x, startHeight / 2f, transform.position.z);

            SetControllerHeight(startHeight);

            LogMessage("Player movement initialized successfully");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] Initialization error: {ex.Message}");
            enabled = false;
        }
    }

    /// <summary>
    /// Process input and handle player movement each frame
    /// </summary>
    private void Update()
    {
        try
        {
            ProcessInputs();
            UpdateGroundStatus();
            HandleStanceLogic();
            CalculateMovement();
            ApplyMovement();
            UpdateCameraHeight();
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] Update error: {ex.Message}\nStackTrace: {ex.StackTrace}");
        }
    }

    /// <summary>
    /// Update physics-related properties in FixedUpdate for consistency
    /// </summary>
    private void FixedUpdate()
    {
        try
        {
            UpdateColliderHeight();
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] FixedUpdate error: {ex.Message}");
        }
    }

    /// <summary>
    /// Draw debug visualization in the editor
    /// </summary>
    private void OnDrawGizmosSelected()
    {
        if (!showDebugGizmos) return;

        if (groundCheck != null)
        {
            Gizmos.color = isGrounded ? Color.green : Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundDistance);
        }

        if (Application.isPlaying)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawRay(transform.position, moveDirection * currentSpeed * 0.5f);

            Gizmos.color = Color.red;
            Gizmos.DrawRay(transform.position, velocity * 0.5f);
        }
    }

    #endregion

    #region Input Processing

    /// <summary>
    /// Process player input for movement and stance changes
    /// </summary>
    private void ProcessInputs()
    {
        movementInput.x = Input.GetAxis("Horizontal");
        movementInput.y = Input.GetAxis("Vertical");

        crouchInput = Input.GetKey(crouchKey);
        proneInput = Input.GetKey(proneKey);
        sprintInput = Input.GetKey(sprintKey);

        jumpInput = Input.GetButtonDown("Jump") || Input.GetKeyDown(jumpKey);

        if (proneInput)
        {
            targetStance = PlayerStance.Prone;
        }
        else if (crouchInput)
        {
            targetStance = PlayerStance.Crouch;
        }
        else
        {
            targetStance = PlayerStance.Stand;
        }
    }

    #endregion

    #region Ground Detection

    /// <summary>
    /// Check if player is grounded and handle ground status changes
    /// </summary>
    private void UpdateGroundStatus()
    {
        wasGroundedLastFrame = isGrounded;

        isGrounded = Physics.CheckSphere(
            groundCheck.position,
            groundDistance,
            groundMask,
            QueryTriggerInteraction.Ignore
        );

        if (isGrounded)
        {
            timeSinceGrounded = 0f;

            if (velocity.y < 0)
            {
                velocity.y = -2f;
            }

            if (!wasGroundedLastFrame && isJumping)
            {
                isJumping = false;
                OnLanded();
            }
        }
        else
        {
            timeSinceGrounded += Time.deltaTime;
        }
    }

    /// <summary>
    /// Called when player lands after jumping or falling
    /// </summary>
    private void OnLanded()
    {
        LogMessage("Player landed");
    }

    /// <summary>
    /// Determines if player can jump based on ground status and cooldown
    /// </summary>
    /// <returns>True if player can jump, false otherwise</returns>
    private bool CanJump()
    {
        bool withinCoyoteTime = timeSinceGrounded < COYOTE_TIME;
        bool jumpCooldownElapsed = Time.time > lastJumpTime + JUMP_COOLDOWN;
        bool stanceAllowsJump = currentStance == PlayerStance.Stand || autoStandOnJump;

        return (isGrounded || withinCoyoteTime) && jumpCooldownElapsed && stanceAllowsJump;
    }

    #endregion

    #region Stance Management

    /// <summary>
    /// Handle stance transitions based on input and current state
    /// </summary>
    private void HandleStanceLogic()
    {
        if (isTransitioningStance)
            return;

        if (jumpInput && autoStandOnJump && currentStance != PlayerStance.Stand)
        {
            targetStance = PlayerStance.Stand;
        }

        if (targetStance != currentStance)
        {
            BeginStanceTransition(targetStance);
        }
    }

    /// <summary>
    /// Start the transition to a new stance
    /// </summary>
    /// <param name="newStance">Target stance to transition to</param>
    private void BeginStanceTransition(PlayerStance newStance)
    {
        if (stanceTransitionCoroutine != null)
        {
            StopCoroutine(stanceTransitionCoroutine);
        }

        if (stanceTransitionTime > 0)
        {
            stanceTransitionCoroutine = StartCoroutine(TransitionToStance(newStance));
        }
        else
        {
            currentStance = newStance;
            currentStanceHeight = GetHeightForStance(newStance);
            stanceTransitionProgress = 1f;
            LogMessage($"Instantly changed stance to {newStance}");
        }
    }

    /// <summary>
    /// Coroutine to smoothly transition between stances
    /// </summary>
    private IEnumerator TransitionToStance(PlayerStance newStance)
    {
        isTransitioningStance = true;
        stanceTransitionProgress = 0f;

        float startHeight = currentStanceHeight;
        float targetHeight = GetHeightForStance(newStance);

        LogMessage($"Transitioning from {currentStance} to {newStance}");

        while (stanceTransitionProgress < 1f)
        {
            stanceTransitionProgress += Time.deltaTime / stanceTransitionTime;
            currentStanceHeight = Mathf.Lerp(startHeight, targetHeight, Mathf.Clamp01(stanceTransitionProgress));

            yield return null;
        }

        // Finalize transition
        currentStance = newStance;
        isTransitioningStance = false;
        stanceTransitionCoroutine = null;

        LogMessage($"Completed transition to {newStance}");
    }

    /// <summary>
    /// Get the character controller height for the specified stance
    /// </summary>
    /// <param name="stance">Player stance</param>
    /// <returns>Height value for the stance</returns>
    private float GetHeightForStance(PlayerStance stance)
    {
        switch (stance)
        {
            case PlayerStance.Prone: return 1.0f;
            case PlayerStance.Crouch: return 1.5f;
            case PlayerStance.Stand: default: return 2.0f;
        }
    }

    /// <summary>
    /// Update the camera position based on current stance
    /// </summary>
    private void UpdateCameraHeight()
    {
        if (cameraHolder == null) return;

        float targetY;

        switch (currentStance)
        {
            case PlayerStance.Crouch:
                targetY = crouchCamY;
                break;
            case PlayerStance.Prone:
                targetY = proneCamY;
                break;
            case PlayerStance.Stand:
            default:
                targetY = standCamY;
                break;
        }

        if (isTransitioningStance)
        {
            switch (targetStance)
            {
                case PlayerStance.Crouch:
                    targetY = Mathf.Lerp(
                        currentStance == PlayerStance.Stand ? standCamY : proneCamY,
                        crouchCamY,
                        stanceTransitionProgress);
                    break;
                case PlayerStance.Prone:
                    targetY = Mathf.Lerp(
                        currentStance == PlayerStance.Stand ? standCamY : crouchCamY,
                        proneCamY,
                        stanceTransitionProgress);
                    break;
                case PlayerStance.Stand:
                    targetY = Mathf.Lerp(
                        currentStance == PlayerStance.Crouch ? crouchCamY : proneCamY,
                        standCamY,
                        stanceTransitionProgress);
                    break;
            }
        }

        Vector3 camPos = cameraHolder.localPosition;
        camPos.y = Mathf.Lerp(camPos.y, targetY, Time.deltaTime * cameraLerpSpeed);
        cameraHolder.localPosition = camPos;
    }

    /// <summary>
    /// Update the character controller's height and center based on stance
    /// </summary>
    private void UpdateColliderHeight()
    {
        if (controller == null) return;

        SetControllerHeight(currentStanceHeight);
    }

    /// <summary>
    /// Set the character controller height and adjust center point
    /// </summary>
    /// <param name="height">New controller height</param>
    private void SetControllerHeight(float height)
    {
        try
        {
            controller.height = height;
            controller.center = new Vector3(0, height / 2f, 0);
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] Error setting controller height: {ex.Message}");
        }
    }

    #endregion

    #region Movement Calculations

    /// <summary>
    /// Calculate movement direction, speed, and handle jumping
    /// </summary>
    private void CalculateMovement()
    {
        targetSpeed = walkSpeed;

        switch (currentStance)
        {
            case PlayerStance.Prone:
                targetSpeed = proneSpeed;
                break;

            case PlayerStance.Crouch:
                targetSpeed = crouchSpeed;
                break;

            case PlayerStance.Stand:
                bool canSprint = !forwardSprintOnly || movementInput.y > 0.1f;
                targetSpeed = (sprintInput && canSprint) ? sprintSpeed : walkSpeed;
                break;
        }

        currentSpeed = Mathf.Lerp(currentSpeed, targetSpeed, Time.deltaTime * groundAcceleration);

        Vector3 move = Vector3.zero;
        if (movementInput.sqrMagnitude > 0.01f)
        {
            move = transform.right * movementInput.x + transform.forward * movementInput.y;

            if (move.sqrMagnitude > 1f)
            {
                move.Normalize();
            }

            if (!isGrounded && limitAirControl)
            {
                move *= airControlFactor;
            }
        }

        moveDirection = move;

        if (jumpInput && CanJump())
        {
            PerformJump();
        }

        ApplyGravity();
    }

    /// <summary>
    /// Execute jump and handle related effects
    /// </summary>
    private void PerformJump()
    {
        velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        isJumping = true;
        lastJumpTime = Time.time;

        LogMessage("Player jumped");

        if (autoStandOnJump && currentStance != PlayerStance.Stand)
        {
            targetStance = PlayerStance.Stand;
        }
    }

    /// <summary>
    /// Apply gravity to vertical velocity
    /// </summary>
    private void ApplyGravity()
    {
        float terminalVelocity = -20f;
        velocity.y += gravity * Time.deltaTime;
        velocity.y = Mathf.Max(velocity.y, terminalVelocity);
    }

    /// <summary>
    /// Apply final movement to character controller
    /// </summary>
    private void ApplyMovement()
    {
        if (controller == null) return;

        try
        {
            controller.Move(moveDirection * currentSpeed * Time.deltaTime);

            controller.Move(velocity * Time.deltaTime);
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] Error applying movement: {ex.Message}");
        }
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Check if player is currently moving
    /// </summary>
    /// <returns>True if moving, false otherwise</returns>
    public virtual bool IsMoving()
    {
        return movementInput.sqrMagnitude > 0.01f;
    }

    /// <summary>
    /// Check if player is currently on the ground
    /// </summary>
    /// <returns>True if grounded, false otherwise</returns>
    public virtual bool IsGrounded()
    {
        return isGrounded;
    }

    /// <summary>
    /// Get the current player stance as a string
    /// </summary>
    /// <returns>Current stance name</returns>
    public virtual string GetCurrentStance()
    {
        return currentStance.ToString();
    }

    /// <summary>
    /// Get the current movement speed
    /// </summary>
    /// <returns>Current speed in units per second</returns>
    public virtual float GetCurrentSpeed()
    {
        return currentSpeed;
    }

    /// <summary>
    /// Check if player is currently jumping
    /// </summary>
    /// <returns>True if jumping, false otherwise</returns>
    public virtual bool IsJumping()
    {
        return isJumping;
    }

    /// <summary>
    /// Force player to a specific stance
    /// </summary>
    /// <param name="stanceName">Name of stance to enter: "Stand", "Crouch", or "Prone"</param>
    public virtual void ForceStance(string stanceName)
    {
        try
        {
            PlayerStance newStance = (PlayerStance)Enum.Parse(typeof(PlayerStance), stanceName, true);
            targetStance = newStance;
            BeginStanceTransition(newStance);
        }
        catch (Exception ex)
        {
            Debug.LogError($"[PlayerMovement] Error forcing stance: {ex.Message}");
        }
    }

    /// <summary>
    /// Set the player's vertical velocity directly
    /// </summary>
    /// <param name="value">New vertical velocity</param>
    public virtual void SetVerticalVelocity(float value)
    {
        velocity.y = value;
    }

    /// <summary>
    /// Reset all movement state to defaults
    /// </summary>
    public virtual void ResetMovementState()
    {
        velocity = Vector3.zero;
        moveDirection = Vector3.zero;
        currentSpeed = 0f;
        isJumping = false;

        ForceStance("Stand");
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Validate that required references are assigned
    /// </summary>
    private void ValidateRequiredReferences()
    {
        if (groundCheck == null)
        {
            Debug.LogWarning("[PlayerMovement] GroundCheck not assigned! Ground detection will not work.");
        }

        if (cameraHolder == null)
        {
            Debug.LogWarning("[PlayerMovement] CameraHolder not assigned! Camera positioning will not work.");
        }

        if (groundMask.value == 0)
        {
            Debug.LogWarning("[PlayerMovement] Ground mask not set! Ground detection may not work properly.");
        }
    }

    /// <summary>
    /// Log a debug message if debug logging is enabled
    /// </summary>
    /// <param name="message">Message to log</param>
    private void LogMessage(string message)
    {
        if (enableDebugLogs)
        {
            Debug.Log($"[PlayerMovement] {message}");
        }
    }

    #endregion
}