using UnityEngine;
using System;
using System.Collections;

public class ColorCube : MonoBehaviour, IInteractable
{
    [Header("Cube Configuration")]
    public string colorName = "Unknown";
    [SerializeField] private float moveDistance = 1.0f;
    [SerializeField] private float moveDuration = 0.5f;
    [SerializeField] private float highlightIntensity = 1.25f;

    [Header("Debug Settings")]
    [SerializeField] private bool enableDebugLogs = true;
    [SerializeField] private bool enableAnimations = true;

    private bool isUp = false;
    private bool isMoving = false;
    private Renderer rend;
    private Color originalColor;
    private Vector3 initialPosition;
    private bool isInitialized = false;

    public enum MoveState
    {
        Idle,
        MovingUp,
        MovingDown
    }

    private MoveState currentMoveState = MoveState.Idle;

    private void Awake()
    {
        try
        {
            InitializeComponents();
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Failed to initialize: {e.Message}");
        }
    }

    private void Start()
    {
        try
        {
            initialPosition = transform.position;
            ValidateConfiguration();
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Error during Start: {e.Message}");
        }
    }

    private void InitializeComponents()
    {
        rend = GetComponent<Renderer>();

        if (rend == null)
        {
            throw new MissingComponentException($"[ColorCube] Missing Renderer component on {gameObject.name}");
        }

        originalColor = rend.material.color;
        isInitialized = true;

        if (string.IsNullOrEmpty(colorName) || colorName == "Unknown")
        {
            colorName = ColorUtility.ToHtmlStringRGB(originalColor);
            Debug.Log($"[ColorCube] Color name was unspecified, set to: {colorName}");
        }
    }

    private void ValidateConfiguration()
    {
        if (moveDistance <= 0)
        {
            Debug.LogWarning($"[ColorCube] Invalid move distance ({moveDistance}), setting to default 1.0");
            moveDistance = 1.0f;
        }

        if (moveDuration <= 0)
        {
            Debug.LogWarning($"[ColorCube] Invalid move duration ({moveDuration}), setting to default 0.5");
            moveDuration = 0.5f;
        }

        if (highlightIntensity <= 0 || highlightIntensity > 2.0f)
        {
            Debug.LogWarning($"[ColorCube] Invalid highlight intensity ({highlightIntensity}), setting to default 1.25");
            highlightIntensity = 1.25f;
        }
    }

    public void Interact()
    {
        if (!isInitialized)
        {
            Debug.LogError("[ColorCube] Cannot interact - cube is not properly initialized");
            return;
        }

        if (isMoving)
        {
            if (enableDebugLogs)
            {
                Debug.Log($"[{colorName}] Movement already in progress, ignoring interaction");
            }
            return;
        }

        try
        {
            if (enableAnimations)
            {
                StartCoroutine(MoveWithAnimation());
            }
            else
            {
                MoveInstantly();
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Error during interaction: {e.Message}");
            isMoving = false;
        }
    }

    private void MoveInstantly()
    {
        Vector3 direction = isUp ? Vector3.down : Vector3.up;
        transform.position += direction * moveDistance;

        if (enableDebugLogs)
        {
            Debug.Log($"[{colorName}] moved {(isUp ? "DOWN" : "UP")}");
        }

        isUp = !isUp;
        currentMoveState = MoveState.Idle;
    }

    private IEnumerator MoveWithAnimation()
    {
        isMoving = true;

        Vector3 targetPosition;
        string directionStr;

        if (!isUp)
        {
            targetPosition = transform.position + Vector3.up * moveDistance;
            currentMoveState = MoveState.MovingUp;
            directionStr = "UP";
        }
        else
        {
            targetPosition = transform.position - Vector3.up * moveDistance;
            currentMoveState = MoveState.MovingDown;
            directionStr = "DOWN";
        }

        if (enableDebugLogs)
        {
            Debug.Log($"[{colorName}] starting to move {directionStr}");
        }

        float elapsedTime = 0;
        Vector3 startPosition = transform.position;

        while (elapsedTime < moveDuration)
        {
            transform.position = Vector3.Lerp(startPosition, targetPosition, elapsedTime / moveDuration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        transform.position = targetPosition;

        if (enableDebugLogs)
        {
            Debug.Log($"[{colorName}] finished moving {directionStr}");
        }

        isUp = !isUp;
        isMoving = false;
        currentMoveState = MoveState.Idle;
    }

    public void Highlight(bool on)
    {
        if (!isInitialized)
        {
            Debug.LogWarning("[ColorCube] Cannot highlight - cube is not properly initialized");
            return;
        }

        try
        {
            ApplyHighlight(on);
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Error during highlight: {e.Message}");
        }
    }

    private void ApplyHighlight(bool on)
    {
        if (rend == null)
        {
            Debug.LogError("[ColorCube] Renderer is null during highlight");
            return;
        }

        if (on)
        {
            Color highlightedColor = originalColor * highlightIntensity;
            highlightedColor.a = 1f;

            highlightedColor.r = Mathf.Clamp01(highlightedColor.r);
            highlightedColor.g = Mathf.Clamp01(highlightedColor.g);
            highlightedColor.b = Mathf.Clamp01(highlightedColor.b);

            rend.material.color = highlightedColor;

            if (enableDebugLogs)
            {
                Debug.Log($"[{colorName}] Highlighted with intensity {highlightIntensity}");
            }
        }
        else
        {
            rend.material.color = originalColor;

            if (enableDebugLogs)
            {
                Debug.Log($"[{colorName}] Highlight removed");
            }
        }
    }

    public void ResetPosition()
    {
        try
        {
            StopAllCoroutines();
            transform.position = initialPosition;
            isUp = false;
            isMoving = false;
            currentMoveState = MoveState.Idle;

            if (enableDebugLogs)
            {
                Debug.Log($"[{colorName}] Position reset to initial");
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Error during position reset: {e.Message}");
        }
    }

    public void SetHighlightIntensity(float intensity)
    {
        if (intensity <= 0 || intensity > 2.0f)
        {
            Debug.LogWarning($"[ColorCube] Invalid highlight intensity ({intensity}), value must be between 0 and 2.0");
            return;
        }

        highlightIntensity = intensity;

        if (enableDebugLogs)
        {
            Debug.Log($"[{colorName}] Highlight intensity set to {highlightIntensity}");
        }
    }

    public bool IsMoving()
    {
        return isMoving;
    }

    public bool IsUp()
    {
        return isUp;
    }

    public MoveState GetMoveState()
    {
        return currentMoveState;
    }

    public void ToggleDebugLogs(bool enable)
    {
        enableDebugLogs = enable;
    }

    public void ToggleAnimations(bool enable)
    {
        enableAnimations = enable;
    }

    private void OnDestroy()
    {
        try
        {
            StopAllCoroutines();
        }
        catch (Exception e)
        {
            Debug.LogError($"[ColorCube] Error during OnDestroy: {e.Message}");
        }
    }
}
