using UnityEngine;

public class MainMenuUI : MonoBehaviour
{
    public GameObject mainPanel;
    public GameObject optionsPanel;
    public GameObject levelPanel;

    private void Start()
    {
        ShowMain();
    }

    public void ShowOptions()
    {
        mainPanel.SetActive(false);
        levelPanel.SetActive(false);
        optionsPanel.SetActive(true);
    }

    public void ShowMain()
    {
        mainPanel.SetActive(true);
        optionsPanel.SetActive(false);
        levelPanel.SetActive(false);
    }

    public void ShowLevel()
    {
        mainPanel.SetActive(false);
        optionsPanel.SetActive(false);
        levelPanel.SetActive(true);
    }
}
