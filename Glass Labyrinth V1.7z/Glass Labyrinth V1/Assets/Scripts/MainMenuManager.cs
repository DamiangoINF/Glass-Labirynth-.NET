using UnityEngine;
using UnityEngine.SceneManagement;
public class MainMenuManager : MonoBehaviour
{
    public void StartTests()
    {
        SceneManager.LoadScene(1);
    }

    public void StartLevel1()
    {
        SceneManager.LoadScene(2);
    }
    public void StartLevel2()
    {
        Debug.Log("Level in the making");
    }
    public void StartLevel3()
    {
        Debug.Log("Level in the making");
    }
    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Quit called (won't work in editor)");
    }
}