using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Assertions;

/// <summary>
/// Controls camera movement, mouse look functionality, and headbob effects
/// for first-person player movement.
/// </summary>
public class CameraController : MonoBehaviour
{
    #region Inspector Fields

    [Header("Mouse Settings")]
    [Range(50f, 500f)]
    [Tooltip("Controls how sensitive the mouse movement is")]
    public float mouseSensitivity = 200f;

    [Range(0.1f, 1f)]
    [Tooltip("Smoothing time for mouse movement")]
    public float dragSmoothTime = 0.2f;

    [Header("Headbob Settings")]
    [Range(1f, 20f)]
    [Tooltip("Speed of the headbob effect")]
    public float bobSpeed = 10f;

    [Range(0.01f, 0.2f)]
    [Tooltip("Amount of headbob effect")]
    public float bobAmount = 0.05f;

    [Header("References")]
    [Tooltip("Transform that holds the camera")]
    public Transform cameraHolder;

    [Tooltip("Reference to the player movement script")]
    public PlayerMovement playerMovement;

    [Header("Advanced Settings")]
    [Range(1f, 12f)]
    [Tooltip("Speed at which the camera returns to default position")]
    public float returnToDefaultSpeed = 6f;

    [Range(-90f, 0f)]
    [Tooltip("Minimum vertical angle the camera can look")]
    public float minVerticalAngle = -90f;

    [Range(0f, 90f)]
    [Tooltip("Maximum vertical angle the camera can look")]
    public float maxVerticalAngle = 90f;

    #endregion

    #region Private Fields

    private float xRotation = 0f;
    private float defaultYPos = 0f;

    private Vector2 currentMouseDelta = Vector2.zero;
    private Vector2 currentMouseDeltaVelocity = Vector2.zero;

    private float bobTimer = 0f;

    private bool isInitialized = false;

    private StanceMultipliers stanceMultipliers;

    /// <summary>
    /// Struct to store headbob multipliers for different player stances
    /// </summary>
    private struct StanceMultipliers
    {
        public float standing;
        public float crouching;
        public float prone;
    }

    #endregion

    #region Unity Lifecycle Methods

    /// <summary>
    /// Initialize values and validate components on Awake
    /// </summary>
    private void Awake()
    {
        try
        {
            stanceMultipliers = new StanceMultipliers
            {
                standing = 1.0f,
                crouching = 0.5f,
                prone = 0.2f
            };

            ValidateComponents();
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error during CameraController initialization: {ex.Message}");
            enabled = false;
        }
    }

    /// <summary>
    /// Set up cursor state and initialize values on Start
    /// </summary>
    private void Start()
    {
        try
        {
            SetCursorState(CursorLockMode.Locked);

            defaultYPos = transform.localPosition.y;

            isInitialized = true;

            Debug.Log("CameraController initialized successfully");
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error during CameraController start: {ex.Message}");
            enabled = false;
        }
    }

    /// <summary>
    /// Process camera movement and headbob each frame
    /// </summary>
    private void Update()
    {
        if (!isInitialized)
        {
            return;
        }

        try
        {
            HandleMouseLook();
            HandleHeadbob();
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error during CameraController update: {ex.Message}");
        }
    }

    #endregion

    #region Component Validation

    /// <summary>
    /// Validate that required components are assigned
    /// </summary>
    /// <exception cref="NullReferenceException">Thrown if required references are missing</exception>
    private void ValidateComponents()
    {
        if (cameraHolder == null)
        {
            throw new NullReferenceException("Camera holder reference is not assigned in the inspector");
        }

        if (playerMovement == null)
        {
            throw new NullReferenceException("Player movement reference is not assigned in the inspector");
        }
    }

    #endregion

    #region Mouse Look Handling

    /// <summary>
    /// Process mouse input and apply camera rotation
    /// </summary>
    private void HandleMouseLook()
    {
        try
        {
            Vector2 mouseInput = GetMouseInput();

            Vector2 targetMouseDelta = new Vector2(mouseInput.x, mouseInput.y);
            currentMouseDelta = Vector2.SmoothDamp(
                currentMouseDelta,
                targetMouseDelta,
                ref currentMouseDeltaVelocity,
                dragSmoothTime
            );

            float deltaTimeMultiplier = Time.deltaTime * mouseSensitivity;
            float verticalRotation = currentMouseDelta.y * deltaTimeMultiplier;
            float horizontalRotation = currentMouseDelta.x * deltaTimeMultiplier;

            ApplyVerticalRotation(verticalRotation);

            ApplyHorizontalRotation(horizontalRotation);
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"Error in mouse look handling: {ex.Message}");
        }
    }

    /// <summary>
    /// Get raw mouse input from input system
    /// </summary>
    /// <returns>Vector2 containing x and y mouse movement</returns>
    private Vector2 GetMouseInput()
    {
        float mouseX = 0f;
        float mouseY = 0f;

        try
        {
            mouseX = Input.GetAxis("Mouse X");
            mouseY = Input.GetAxis("Mouse Y");
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"Failed to get mouse input: {ex.Message}");
        }

        return new Vector2(mouseX, mouseY);
    }

    /// <summary>
    /// Apply vertical (pitch) rotation to camera, with clamping
    /// </summary>
    /// <param name="rotationAmount">Amount to rotate in degrees</param>
    private void ApplyVerticalRotation(float rotationAmount)
    {
        xRotation -= rotationAmount;

        xRotation = Mathf.Clamp(xRotation, minVerticalAngle, maxVerticalAngle);

        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
    }

    /// <summary>
    /// Apply horizontal (yaw) rotation to camera holder
    /// </summary>
    /// <param name="rotationAmount">Amount to rotate in degrees</param>
    private void ApplyHorizontalRotation(float rotationAmount)
    {
        if (cameraHolder != null)
        {
            cameraHolder.Rotate(Vector3.up * rotationAmount);
        }
        else
        {
            Debug.LogWarning("Cannot apply horizontal rotation: camera holder is null");
        }
    }

    #endregion

    #region Headbob Handling

    /// <summary>
    /// Handle camera headbob effect based on player movement
    /// </summary>
    private void HandleHeadbob()
    {
        try
        {
            bool isHeadbobActive = ShouldApplyHeadbob();

            if (!isHeadbobActive)
            {
                ResetHeadbob();
                return;
            }

            float stanceMultiplier = GetStanceMultiplier();

            UpdateBobTimer(stanceMultiplier);

            ApplyHeadbobEffect(stanceMultiplier);
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"Error in headbob handling: {ex.Message}");
        }
    }

    /// <summary>
    /// Determine if headbob effect should be applied based on player state
    /// </summary>
    /// <returns>True if headbob should be active, false otherwise</returns>
    private bool ShouldApplyHeadbob()
    {
        if (playerMovement == null)
        {
            return false;
        }

        return playerMovement.IsMoving() && playerMovement.IsGrounded();
    }

    /// <summary>
    /// Reset headbob and return camera to default position
    /// </summary>
    private void ResetHeadbob()
    {
        bobTimer = 0f;

        Vector3 currentPosition = transform.localPosition;
        float newY = Mathf.Lerp(currentPosition.y, defaultYPos, Time.deltaTime * returnToDefaultSpeed);
        transform.localPosition = new Vector3(currentPosition.x, newY, currentPosition.z);
    }

    /// <summary>
    /// Get multiplier for headbob effect based on player stance
    /// </summary>
    /// <returns>Multiplier value for current stance</returns>
    private float GetStanceMultiplier()
    {
        if (playerMovement == null)
        {
            return stanceMultipliers.standing;
        }

        string currentStance = playerMovement.GetCurrentStance();

        switch (currentStance)
        {
            case "Stand":
                return stanceMultipliers.standing;
            case "Crouch":
                return stanceMultipliers.crouching;
            case "Prone":
                return stanceMultipliers.prone;
            default:
                Debug.LogWarning($"Unknown stance: {currentStance}, using default");
                return stanceMultipliers.standing;
        }
    }

    /// <summary>
    /// Update the bobbing timer based on time and player state
    /// </summary>
    /// <param name="stanceMultiplier">Multiplier for current stance</param>
    private void UpdateBobTimer(float stanceMultiplier)
    {
        float increment = Time.deltaTime * bobSpeed * stanceMultiplier;
        bobTimer += increment;

        if (bobTimer > Mathf.PI * 2)
        {
            bobTimer -= Mathf.PI * 2;
        }
    }

    /// <summary>
    /// Apply vertical position change based on headbob effect
    /// </summary>
    /// <param name="stanceMultiplier">Multiplier for current stance</param>
    private void ApplyHeadbobEffect(float stanceMultiplier)
    {
        float bobEffect = Mathf.Sin(bobTimer) * bobAmount * stanceMultiplier;
        float newY = defaultYPos + bobEffect;

        Vector3 currentPosition = transform.localPosition;
        transform.localPosition = new Vector3(currentPosition.x, newY, currentPosition.z);
    }

    #endregion

    #region Public Methods

    /// <summary>
    /// Set the cursor lock state and visibility
    /// </summary>
    /// <param name="lockMode">Desired cursor lock mode</param>
    public void SetCursorState(CursorLockMode lockMode)
    {
        try
        {
            Cursor.lockState = lockMode;
            Cursor.visible = lockMode != CursorLockMode.Locked;
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"Failed to set cursor state: {ex.Message}");
        }
    }

    /// <summary>
    /// Get the current vertical rotation angle (pitch)
    /// </summary>
    /// <returns>Current pitch angle in degrees</returns>
    public float GetCurrentPitch()
    {
        return xRotation;
    }

    /// <summary>
    /// Get the current horizontal rotation angle (yaw)
    /// </summary>
    /// <returns>Current yaw angle in degrees</returns>
    public float GetCurrentYaw()
    {
        if (cameraHolder != null)
        {
            return cameraHolder.eulerAngles.y;
        }
        return 0f;
    }

    /// <summary>
    /// Change the mouse sensitivity setting
    /// </summary>
    /// <param name="sensitivity">New sensitivity value</param>
    /// <returns>True if successful, false if out of valid range</returns>
    public bool SetMouseSensitivity(float sensitivity)
    {
        try
        {
            if (sensitivity < 50f || sensitivity > 500f)
            {
                Debug.LogWarning($"Mouse sensitivity out of range: {sensitivity}");
                return false;
            }

            mouseSensitivity = sensitivity;
            return true;
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error setting mouse sensitivity: {ex.Message}");
            return false;
        }
    }

    /// <summary>
    /// Apply test mouse input for debugging or testing
    /// </summary>
    /// <param name="x">Horizontal input value</param>
    /// <param name="y">Vertical input value</param>
    public void TestMouseInput(float x, float y)
    {
        try
        {
            Vector2 testInput = new Vector2(x, y);

            Vector2 smoothedInput = Vector2.SmoothDamp(
                currentMouseDelta,
                testInput,
                ref currentMouseDeltaVelocity,
                dragSmoothTime
            );

            float deltaTimeMultiplier = Time.deltaTime * mouseSensitivity;

            ApplyVerticalRotation(smoothedInput.y * deltaTimeMultiplier);
            ApplyHorizontalRotation(smoothedInput.x * deltaTimeMultiplier);

            Debug.Log($"Test mouse input applied: ({x}, {y})");
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error during test mouse input: {ex.Message}");
        }
    }

    /// <summary>
    /// Reset camera to default orientation and position
    /// </summary>
    public void ResetCamera()
    {
        try
        {
            xRotation = 0f;
            transform.localRotation = Quaternion.identity;

            if (cameraHolder != null)
            {
                cameraHolder.localRotation = Quaternion.identity;
            }

            bobTimer = 0f;
            transform.localPosition = new Vector3(transform.localPosition.x, defaultYPos, transform.localPosition.z);

            Debug.Log("Camera reset to default orientation");
        }
        catch (Exception ex)
        {
            Debug.LogError($"Error resetting camera: {ex.Message}");
        }
    }

    #endregion
}