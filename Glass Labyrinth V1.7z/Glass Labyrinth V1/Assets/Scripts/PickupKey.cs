using UnityEngine;

public class PickupKey : MonoBehaviour, IInteractable
{
    public string keyID = "DefaultKey";

    private Renderer rend;
    private Color originalColor;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        originalColor = rend.material.color;
    }

    public void Interact()
    {
        KeyInventory.AddKey(keyID);
        Debug.Log($"Picked up key: {keyID}");
        Destroy(gameObject);
    }

    public void Highlight(bool on)
    {
        if (rend == null) return;

        if (on)
        {
            Color highlighted = originalColor * 1.25f;
            highlighted.a = 1f;
            rend.material.color = highlighted;
        }
        else
        {
            rend.material.color = originalColor;
        }
    }
}
