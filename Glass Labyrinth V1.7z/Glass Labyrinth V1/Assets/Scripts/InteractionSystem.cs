using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// Handles player interaction with objects implementing the IInteractable interface.
/// Casts a ray from the camera and detects interactable objects, allowing for interaction
/// and special handling for movable objects.
/// </summary>
public class InteractionSystem : MonoBehaviour
{
    #region Inspector Fields

    [Header("Interaction Settings")]
    [Tooltip("Maximum distance player can interact with objects")]
    [Range(1f, 10f)]
    public float interactionDistance = 3f;

    [Tooltip("Layer mask for objects that can be interacted with")]
    public LayerMask interactionMask;

    [Tooltip("Key used to interact with objects")]
    public KeyCode interactKey = KeyCode.E;

    [Header("UI Feedback")]
    [Tooltip("Optional event triggered when looking at an interactable")]
    public UnityEvent<bool> onInteractableInSight;

    [Header("Debug")]
    [Tooltip("Enable visual debugging in scene view")]
    public bool showDebugRay = false;

    [Tooltip("Color of debug ray when hitting an interactable")]
    public Color hitColor = Color.green;

    [Tooltip("Color of debug ray when not hitting anything")]
    public Color missColor = Color.red;

    #endregion

    #region Private Fields

    private Camera playerCamera;
    private IInteractable currentInteractable;
    private bool wasLookingAtInteractable = false;

    #endregion

    #region Unity Lifecycle Methods

    private void Awake()
    {
        TryFindCamera();
    }

    private void Start()
    {
        if (playerCamera == null)
        {
            Debug.LogError("[InteractionSystem] No camera found! Interaction system will not function correctly.");
        }
    }

    private void Update()
    {
        if (playerCamera == null)
        {
            TryFindCamera();
            return;
        }

        CheckForInteractables();
        HandleInteractionInput();
    }

    private void OnDrawGizmos()
    {
        if (!showDebugRay || playerCamera == null) return;

        Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));
        bool hitSomething = Physics.Raycast(ray, out RaycastHit hit, interactionDistance, interactionMask);

        Gizmos.color = hitSomething ? hitColor : missColor;
        Gizmos.DrawLine(ray.origin, ray.origin + ray.direction * (hitSomething ? hit.distance : interactionDistance));
    }

    #endregion

    #region Core Interaction Methods

    /// <summary>
    /// Checks for interactable objects in front of the player camera
    /// </summary>
    private void CheckForInteractables()
    {
        Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));
        bool isLookingAtInteractable = false;

        if (Physics.Raycast(ray, out RaycastHit hit, interactionDistance, interactionMask))
        {
            IInteractable interactable = hit.collider.GetComponent<IInteractable>();

            if (interactable != currentInteractable)
            {
                if (currentInteractable != null)
                {
                    currentInteractable.Highlight(false);
                }

                if (interactable != null)
                {
                    interactable.Highlight(true);
                    isLookingAtInteractable = true;
                }

                currentInteractable = interactable;
            }
            else if (interactable != null)
            {
                isLookingAtInteractable = true;
            }
        }
        else
        {
            if (currentInteractable != null)
            {
                currentInteractable.Highlight(false);
                currentInteractable = null;
            }
        }

        if (wasLookingAtInteractable != isLookingAtInteractable)
        {
            wasLookingAtInteractable = isLookingAtInteractable;
            onInteractableInSight?.Invoke(isLookingAtInteractable);
        }
    }

    /// <summary>
    /// Handles player input for interaction and movement controls
    /// </summary>
    private void HandleInteractionInput()
    {
        if (currentInteractable == null) return;

        if (Input.GetKeyDown(interactKey))
        {
            currentInteractable.Interact();
        }

        if (currentInteractable is MovableCube cube)
        {
            HandleMovableCubeInput(cube);
        }
    }

    /// <summary>
    /// Processes input specifically for MovableCube objects
    /// </summary>
    /// <param name="cube">The MovableCube to process input for</param>
    private void HandleMovableCubeInput(MovableCube cube)
    {
        if (Input.GetKeyDown(KeyCode.Keypad8)) cube.Move(Vector3.forward);
        if (Input.GetKeyDown(KeyCode.Keypad2)) cube.Move(Vector3.back);
        if (Input.GetKeyDown(KeyCode.Keypad4)) cube.Move(Vector3.left);
        if (Input.GetKeyDown(KeyCode.Keypad6)) cube.Move(Vector3.right);
        if (Input.GetKeyDown(KeyCode.Keypad9)) cube.Move(Vector3.up);
        if (Input.GetKeyDown(KeyCode.Keypad3)) cube.Move(Vector3.down);

        if (Input.GetKeyDown(KeyCode.UpArrow)) cube.Move(Vector3.forward);
        if (Input.GetKeyDown(KeyCode.DownArrow)) cube.Move(Vector3.back);
        if (Input.GetKeyDown(KeyCode.LeftArrow)) cube.Move(Vector3.left);
        if (Input.GetKeyDown(KeyCode.RightArrow)) cube.Move(Vector3.right);
        if (Input.GetKeyDown(KeyCode.PageUp)) cube.Move(Vector3.up);
        if (Input.GetKeyDown(KeyCode.PageDown)) cube.Move(Vector3.down);
    }

    #endregion

    #region Utility Methods

    /// <summary>
    /// Attempts to find the main camera if not already assigned
    /// </summary>
    private void TryFindCamera()
    {
        if (playerCamera == null)
        {
            playerCamera = Camera.main;

            if (playerCamera == null)
            {
                playerCamera = GetComponentInChildren<Camera>();

                if (playerCamera == null)
                {
                    playerCamera = GetComponentInParent<Camera>();
                }
            }
        }
    }

    /// <summary>
    /// Manually sets the camera used for interaction
    /// </summary>
    /// <param name="camera">The camera to use</param>
    public void SetCamera(Camera camera)
    {
        playerCamera = camera;
    }

    #endregion
}

