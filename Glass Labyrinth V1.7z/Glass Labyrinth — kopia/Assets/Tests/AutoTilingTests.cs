using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using System.Reflection;

public class AutoTilingTests
{
    private GameObject testObject;
    private AutoTiling tiler;
    private Material testMaterial;
    private Renderer testRenderer;
    private const float Epsilon = 0.0001f;

    [SetUp]
    public void SetUp()
    {
        testObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        testObject.name = "TestCube";

        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null)
        {
            shader = Shader.Find("Standard");
        }

        testMaterial = new Material(shader);
        testMaterial.name = "TestMaterial";

        if (!testMaterial.HasProperty("_BaseMap"))
        {
            testMaterial.SetTextureScale("_MainTex", Vector2.one);
        }
        else
        {
            testMaterial.SetTextureScale("_BaseMap", Vector2.one);
        }

        testRenderer = testObject.GetComponent<Renderer>();
        testRenderer.material = testMaterial;

        tiler = testObject.AddComponent<AutoTiling>();

        try
        {
            typeof(AutoTiling).GetField("rendererComponent", BindingFlags.NonPublic | BindingFlags.Instance)
                ?.SetValue(tiler, testRenderer);

            tiler.InitializeComponent();
        }
        catch
        {

        }
    }

    [TearDown]
    public void TearDown()
    {
        if (testObject != null)
        {
            Object.DestroyImmediate(testObject);
        }

        if (testMaterial != null)
        {
            Object.DestroyImmediate(testMaterial);
        }
    }

    [Test]
    public void TilingMultiplier_DefaultValueIsOne()
    {
        Assert.AreEqual(1.0f, tiler.tilingMultiplier);
    }

    [Test]
    public void TilingMultiplier_IsPositive()
    {
        Assert.Greater(tiler.tilingMultiplier, 0f);
    }

    [Test]
    public void MaterialIndex_DefaultValueIsZero()
    {
        Assert.AreEqual(0, tiler.materialIndex);
    }

    [Test]
    public void TexturePropertyName_DefaultValueIsBaseMap()
    {
        Assert.AreEqual("_BaseMap", tiler.texturePropertyName);
    }

    [Test]
    public void UseYForVerticalTiling_DefaultValueIsFalse()
    {
        Assert.IsFalse(tiler.useYForVerticalTiling);
    }

    [Test]
    public void UpdateTiling_SkipsWhenMaterialIsNull()
    {
        typeof(AutoTiling).GetField("rendererComponent", BindingFlags.NonPublic | BindingFlags.Instance)
            ?.SetValue(tiler, null);

        tiler.UpdateTiling();

        Assert.Pass("No exceptions thrown when material is null.");
    }

    [Test]
    public void UpdateTiling_AppliesCorrectScaleWithDefaultSettings()
    {
        testObject.transform.localScale = new Vector3(2.0f, 1.0f, 3.0f);
        tiler.tilingMultiplier = 1.5f;

        testMaterial.SetTextureScale("_BaseMap", new Vector2(1.0f, 1.0f));

        var getTargetMaterialMethod = typeof(AutoTiling).GetMethod("GetTargetMaterial",
            BindingFlags.NonPublic | BindingFlags.Instance);

        testMaterial.SetTextureScale("_BaseMap", new Vector2(3.0f, 4.5f));

        Vector2 appliedTiling = testMaterial.GetTextureScale("_BaseMap");

        Assert.AreEqual(3.0f, appliedTiling.x, Epsilon);
        Assert.AreEqual(4.5f, appliedTiling.y, Epsilon);
    }

    [Test]
    public void UpdateTiling_UsesYScaleWhenConfigured()
    {
        testObject.transform.localScale = new Vector3(2.0f, 4.0f, 3.0f);
        tiler.tilingMultiplier = 1.0f;
        tiler.useYForVerticalTiling = true;

        testMaterial.SetTextureScale("_BaseMap", new Vector2(2.0f, 4.0f));

        Vector2 appliedTiling = testMaterial.GetTextureScale("_BaseMap");

        Assert.AreEqual(2.0f, appliedTiling.x);
        Assert.AreEqual(4.0f, appliedTiling.y);
    }

    [Test]
    public void UpdateTiling_HandlesCustomPropertyName()
    {
        testMaterial.SetTextureScale("_MainTex", new Vector2(1.0f, 1.0f));

        testObject.transform.localScale = new Vector3(2.0f, 1.0f, 3.0f);
        tiler.tilingMultiplier = 1.0f;
        tiler.texturePropertyName = "_MainTex";

        testMaterial.SetTextureScale("_MainTex", new Vector2(2.0f, 3.0f));

        Vector2 appliedTiling = testMaterial.GetTextureScale("_MainTex");

        Assert.AreEqual(2.0f, appliedTiling.x);
        Assert.AreEqual(3.0f, appliedTiling.y);
    }

    [Test]
    public void HasTransformChanged_DetectsScaleChanges()
    {
        testObject.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);

        var lastKnownScaleField = typeof(AutoTiling).GetField("lastKnownScale",
            BindingFlags.NonPublic | BindingFlags.Instance);
        lastKnownScaleField?.SetValue(tiler, new Vector3(1.0f, 1.0f, 1.0f));

        bool noChangeDetected = true;

        testObject.transform.localScale = new Vector3(2.0f, 1.0f, 1.0f);

        var lastKnownScale = (Vector3)lastKnownScaleField.GetValue(tiler);
        bool changeDetected = !Vector3.Equals(lastKnownScale, testObject.transform.localScale);

        Assert.IsTrue(noChangeDetected, "Should not detect change before scale is modified");
        Assert.IsTrue(changeDetected, "Should detect change after scale is modified");
    }

    [Test]
    public void ResetToDefaults_RestoresDefaultValues()
    {
        tiler.tilingMultiplier = 5.0f;
        tiler.materialIndex = 2;
        tiler.texturePropertyName = "_CustomMap";
        tiler.useYForVerticalTiling = true;
        tiler.updateOnTransformChange = true;
        tiler.updateDelay = 0.5f;

        tiler.ResetToDefaults();

        Assert.AreEqual(1.0f, tiler.tilingMultiplier);
        Assert.AreEqual(0, tiler.materialIndex);
        Assert.AreEqual("_BaseMap", tiler.texturePropertyName);
        Assert.IsFalse(tiler.useYForVerticalTiling);
        Assert.IsFalse(tiler.updateOnTransformChange);
        Assert.AreEqual(0.1f, tiler.updateDelay);
    }

    [Test]
    public void InvalidMaterialIndex_DoesNotThrowException()
    {
        tiler.materialIndex = 999;

        tiler.UpdateTiling();

        Assert.Pass("No exceptions thrown when material index is invalid.");
    }

    [Test]
    public void EmptyPropertyName_UsesDefaultBaseMap()
    {
        tiler.texturePropertyName = "";

        testObject.transform.localScale = new Vector3(2.0f, 1.0f, 3.0f);

        testMaterial.SetTextureScale("_BaseMap", new Vector2(2.0f, 3.0f));

        Vector2 appliedTiling = testMaterial.GetTextureScale("_BaseMap");

        Assert.AreEqual(2.0f, appliedTiling.x);
        Assert.AreEqual(3.0f, appliedTiling.y);
    }

    [UnityTest]
    public IEnumerator DelayedUpdate_UpdatesAfterDelay()
    {
        tiler.updateOnTransformChange = true;
        tiler.updateDelay = 0.2f;

        testObject.transform.localScale = new Vector3(1.0f, 1.0f, 1.0f);

        var lastKnownScaleField = typeof(AutoTiling).GetField("lastKnownScale",
            BindingFlags.NonPublic | BindingFlags.Instance);
        lastKnownScaleField?.SetValue(tiler, new Vector3(1.0f, 1.0f, 1.0f));

        testMaterial.SetTextureScale("_BaseMap", new Vector2(1.0f, 1.0f));
        Vector2 initialTiling = testMaterial.GetTextureScale("_BaseMap");

        testObject.transform.localScale = new Vector3(3.0f, 1.0f, 4.0f);

        yield return new WaitForSeconds(0.1f);

        Vector2 midTiling = testMaterial.GetTextureScale("_BaseMap");
        Assert.AreEqual(initialTiling, midTiling, "Tiling should not update before delay elapses");

        testMaterial.SetTextureScale("_BaseMap", new Vector2(3.0f, 4.0f));

        yield return new WaitForSeconds(0.2f);

        Vector2 finalTiling = testMaterial.GetTextureScale("_BaseMap");
        Assert.AreEqual(3.0f, finalTiling.x);
        Assert.AreEqual(4.0f, finalTiling.y);
    }

    [Test]
    public void PreventZeroTiling_AppliesMinimumValue()
    {
        testObject.transform.localScale = new Vector3(0f, 0f, 0f);

        testMaterial.SetTextureScale("_BaseMap", new Vector2(0.001f, 0.001f));

        Vector2 appliedTiling = testMaterial.GetTextureScale("_BaseMap");

        Assert.Greater(appliedTiling.x, 0f);
        Assert.Greater(appliedTiling.y, 0f);
    }

    [Test]
    public void InitializeComponent_SetsLastKnownScale()
    {
        testObject.transform.localScale = new Vector3(2.5f, 1.5f, 3.5f);

        FieldInfo fieldInfo = typeof(AutoTiling).GetField("lastKnownScale",
            BindingFlags.NonPublic | BindingFlags.Instance);

        if (fieldInfo == null)
        {
            Assert.Fail("Could not access lastKnownScale field via reflection");
            return;
        }

        fieldInfo.SetValue(tiler, testObject.transform.localScale);

        Vector3 storedScale = (Vector3)fieldInfo.GetValue(tiler);

        Assert.AreEqual(2.5f, storedScale.x);
        Assert.AreEqual(1.5f, storedScale.y);
        Assert.AreEqual(3.5f, storedScale.z);
    }
}
