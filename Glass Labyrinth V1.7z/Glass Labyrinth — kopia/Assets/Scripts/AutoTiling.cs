using System;
using UnityEngine;
using System.Collections;
using Debug = UnityEngine.Debug;

/// <summary>
/// Automatically adjusts texture tiling based on object scale.
/// Attaches to any GameObject with a Renderer component.
/// </summary>
[RequireComponent(typeof(Renderer))]
public class AutoTiling : MonoBehaviour
{
    #region Inspector Fields

    [Header("Tiling Configuration")]
    [Tooltip("Multiplies the tiling factor applied to the material")]
    [Range(0.1f, 10f)]
    public float tilingMultiplier = 1f;

    [Tooltip("The specific material index to modify (for renderers with multiple materials)")]
    [Min(0)]
    public int materialIndex = 0;

    [Tooltip("Optional custom texture property name (defaults to _BaseMap if empty)")]
    public string texturePropertyName = "_BaseMap";

    [Header("Advanced Settings")]
    [Tooltip("If true, uses the Y scale for vertical tiling instead of Z")]
    public bool useYForVerticalTiling = false;

    [Tooltip("If true, automatically updates tiling when transform changes")]
    public bool updateOnTransformChange = false;

    [Tooltip("Optional delay between transform change detection and tiling update")]
    [Range(0f, 1f)]
    public float updateDelay = 0.1f;

    #endregion

    #region Private Fields

    private Renderer rendererComponent;
    private Vector3 lastKnownScale;
    private Coroutine updateCoroutine;
    private bool isInitialized = false;

    #endregion

    #region Unity Lifecycle Methods

    private void Awake()
    {
        try
        {
            InitializeComponent();
        }
        catch (Exception ex)
        {
            Debug.LogError($"[AutoTiling] Failed to initialize: {ex.Message}");
        }
    }

    private void Update()
    {
        if (!isInitialized || !updateOnTransformChange)
        {
            return;
        }

        try
        {
            if (HasTransformChanged())
            {
                ScheduleUpdate();
            }
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[AutoTiling] Error during update check: {ex.Message}");
        }
    }

    private void OnDestroy()
    {
        if (updateCoroutine != null)
        {
            StopCoroutine(updateCoroutine);
            updateCoroutine = null;
        }
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        try
        {
            if (string.IsNullOrEmpty(texturePropertyName))
            {
                texturePropertyName = "_BaseMap";
            }

            if (rendererComponent == null)
            {
                rendererComponent = GetComponent<Renderer>();
            }

            if (rendererComponent != null)
            {
                UpdateTiling();
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[AutoTiling] Error during validation: {ex.Message}");
        }
    }
#endif

    #endregion

    #region Public Methods

    /// <summary>
    /// Initializes component references and performs initial tiling update.
    /// </summary>
    public void InitializeComponent()
    {
        rendererComponent = GetComponent<Renderer>();

        if (rendererComponent == null)
        {
            throw new MissingComponentException("Required Renderer component is missing.");
        }

        lastKnownScale = transform.localScale;
        UpdateTiling();
        isInitialized = true;

        Debug.Log($"[AutoTiling] Successfully initialized on {gameObject.name}");
    }

    /// <summary>
    /// Updates the texture tiling based on current object scale.
    /// </summary>
    public void UpdateTiling()
    {
        if (rendererComponent == null)
        {
            Debug.LogWarning("[AutoTiling] Cannot update tiling: Renderer component is null.");
            return;
        }

        try
        {
            float tileX = Mathf.Max(0.001f, transform.localScale.x * tilingMultiplier);
            float tileY = useYForVerticalTiling
                ? Mathf.Max(0.001f, transform.localScale.y * tilingMultiplier)
                : Mathf.Max(0.001f, transform.localScale.z * tilingMultiplier);

            string propertyToUse = !string.IsNullOrEmpty(texturePropertyName)
                ? texturePropertyName
                : "_BaseMap";

            Material targetMaterial = GetTargetMaterial();

            if (targetMaterial != null)
            {
                if (targetMaterial.HasProperty(propertyToUse))
                {
                    Vector2 newTiling = new Vector2(tileX, tileY);
                    targetMaterial.SetTextureScale(propertyToUse, newTiling);
                    Debug.Log($"[AutoTiling] Updated tiling on {gameObject.name} to {newTiling}");
                }
                else
                {
                    Debug.LogWarning($"[AutoTiling] Property '{propertyToUse}' not found in material shader on {gameObject.name}");
                }
            }

            lastKnownScale = transform.localScale;
        }
        catch (Exception ex)
        {
            Debug.LogError($"[AutoTiling] Error during tiling update: {ex.Message}");
        }
    }

    /// <summary>
    /// Resets all configuration values to their defaults.
    /// </summary>
    public void ResetToDefaults()
    {
        tilingMultiplier = 1f;
        materialIndex = 0;
        texturePropertyName = "_BaseMap";
        useYForVerticalTiling = false;
        updateOnTransformChange = false;
        updateDelay = 0.1f;

        if (isInitialized)
        {
            UpdateTiling();
        }

        Debug.Log($"[AutoTiling] Reset to defaults on {gameObject.name}");
    }

    #endregion

    #region Private Methods

    /// <summary>
    /// Gets the correct material based on the current application state.
    /// </summary>
    private Material GetTargetMaterial()
    {
        try
        {
            if (Application.isPlaying)
            {
                if (rendererComponent.materials.Length > materialIndex)
                {
                    return rendererComponent.materials[materialIndex];
                }
                else
                {
                    Debug.LogWarning($"[AutoTiling] Material index {materialIndex} is out of range (max: {rendererComponent.materials.Length - 1})");
                    return rendererComponent.material;
                }
            }
            else
            {
                if (rendererComponent.sharedMaterials.Length > materialIndex)
                {
                    return rendererComponent.sharedMaterials[materialIndex];
                }
                else
                {
                    Debug.LogWarning($"[AutoTiling] Material index {materialIndex} is out of range (max: {rendererComponent.sharedMaterials.Length - 1})");
                    return rendererComponent.sharedMaterial;
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[AutoTiling] Error accessing material: {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// Checks if the transform's scale has changed since the last update.
    /// </summary>
    private bool HasTransformChanged()
    {
        if (transform == null)
        {
            return false;
        }

        Vector3 currentScale = transform.localScale;

        bool hasChanged =
            !Mathf.Approximately(currentScale.x, lastKnownScale.x) ||
            !Mathf.Approximately(currentScale.y, lastKnownScale.y) ||
            !Mathf.Approximately(currentScale.z, lastKnownScale.z);

        return hasChanged;
    }

    /// <summary>
    /// Schedules a tiling update with optional delay.
    /// </summary>
    private void ScheduleUpdate()
    {
        if (updateCoroutine != null)
        {
            StopCoroutine(updateCoroutine);
        }

        if (updateDelay > 0)
        {
            updateCoroutine = StartCoroutine(DelayedUpdate());
        }
        else
        {
            UpdateTiling();
        }
    }

    /// <summary>
    /// Coroutine that delays the tiling update.
    /// </summary>
    private IEnumerator DelayedUpdate()
    {
        yield return new WaitForSeconds(updateDelay);
        UpdateTiling();
        updateCoroutine = null;
    }

    #endregion
}
