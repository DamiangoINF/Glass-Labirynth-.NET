using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Renderer))]
public class TimedTrigger : MonoBehaviour, IInteractable
{
    public GameObject targetObject;
    public float delay = 5f;

    private bool isActivated = false;
    private Renderer rend;
    private Color originalColor;
    private Vector3 originalTargetPos;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        originalColor = rend.material.color;

        if (targetObject != null)
        {
            originalTargetPos = targetObject.transform.position;
        }
    }

    public void Interact()
    {
        if (!isActivated && targetObject != null)
        {
            Debug.Log($"Activated! Waiting {delay} seconds...");
            isActivated = true;
            StartCoroutine(DelayedAction());
        }
    }

    private IEnumerator DelayedAction()
    {
        yield return new WaitForSeconds(delay);

        targetObject.transform.position += Vector3.up;
        Debug.Log("Target moved up!");

        yield return new WaitForSeconds(delay);

        targetObject.transform.position = originalTargetPos;
        Debug.Log("Target returned to original position.");

        isActivated = false;
    }

    public void Highlight(bool on)
    {
        if (rend == null) return;

        if (on)
        {
            Color highlightedColor = originalColor * 1.25f;
            highlightedColor.a = 1f;
            rend.material.color = highlightedColor;
        }
        else
        {
            rend.material.color = originalColor;
        }
    }
}