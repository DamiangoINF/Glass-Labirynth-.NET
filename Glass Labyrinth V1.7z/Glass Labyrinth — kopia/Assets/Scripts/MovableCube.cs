using System;
using UnityEngine;

public class MovableCube : MonoBehaviour, IInteractable
{
    [Header("Movement Settings")]
    [Tooltip("Distance the cube moves in one step")]
    public float moveAmount = 1f;

    [Header("Collision Settings")]
    [Tooltip("Layers that block movement")]
    public LayerMask obstacleMask;

    [Header("Debug Settings")]
    [SerializeField] private bool logMovementAttempts = true;
    [SerializeField] private bool enableSafetyChecks = true;

    private Renderer rend;
    private Transform cachedTransform;

    private Color originalColor;
    private Vector3 startPosition;

    private int totalMoveAttempts = 0;
    private int successfulMoves = 0;
    private int blockedMoves = 0;

    private void Awake()
    {
        try
        {
            cachedTransform = transform;
            startPosition = cachedTransform.position;

            rend = GetComponent<Renderer>();
            if (rend == null)
            {
                Debug.LogError($"[MovableCube] Renderer component not found on {gameObject.name}");
                enabled = false;
                return;
            }

            originalColor = rend.material != null ?
                rend.material.color :
                Color.white;
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error during initialization: {ex.Message}");
            enabled = false;
        }
    }

    private void Start()
    {
        if (enableSafetyChecks)
        {
            ValidateComponents();
        }
    }

    private void ValidateComponents()
    {
        try
        {
            Collider cubeCollider = GetComponent<Collider>();
            if (cubeCollider == null)
            {
                Debug.LogWarning($"[MovableCube] No collider found on {gameObject.name}. Movement collision detection may not work correctly.");
            }

            if (rend != null && rend.material == null)
            {
                Debug.LogWarning($"[MovableCube] No material found on renderer of {gameObject.name}. Highlighting won't work.");
            }

            if (moveAmount <= 0f || moveAmount > 10f)
            {
                Debug.LogWarning($"[MovableCube] Move amount {moveAmount} seems unusual. Normal range is 0.1-10.");
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error during component validation: {ex.Message}");
        }
    }

    public void Interact()
    {
        try
        {
            Debug.Log("Looking at movable cube. Use NUMPAD keys to move.");

            FlashHighlight();
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error during interaction: {ex.Message}");
        }
    }

    private void FlashHighlight()
    {
        if (rend == null || rend.material == null) return;

        Highlight(true);
        Invoke("ResetHighlight", 0.2f);
    }

    private void ResetHighlight()
    {
        Highlight(false);
    }

    public void Move(Vector3 direction)
    {
        try
        {
            totalMoveAttempts++;

            if (direction == Vector3.zero)
            {
                if (logMovementAttempts)
                {
                    Debug.LogWarning("[MovableCube] Attempted to move with zero direction vector");
                }
                return;
            }

            if (Mathf.Abs(direction.magnitude - 1f) > 0.01f)
            {
                direction = direction.normalized;
                if (logMovementAttempts)
                {
                    Debug.Log("[MovableCube] Normalized non-unit direction vector");
                }
            }

            Vector3 targetPos = cachedTransform.position + direction * moveAmount;

            if (IsOutOfBounds(targetPos))
            {
                blockedMoves++;
                if (logMovementAttempts)
                {
                    Debug.Log($"[MovableCube] Cannot move {gameObject.name} in direction {direction} - would go out of bounds");
                }
                return;
            }

            if (IsObstacleInPath(targetPos, direction))
            {
                blockedMoves++;
                return;
            }

            Vector3 previousPosition = cachedTransform.position;
            cachedTransform.position = targetPos;
            successfulMoves++;

            if (logMovementAttempts)
            {
                Debug.Log($"[MovableCube] Moved {gameObject.name} from {previousPosition} to {targetPos}");
                Debug.Log($"[MovableCube] Move stats: {successfulMoves} successful / {blockedMoves} blocked / {totalMoveAttempts} total");
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error during movement: {ex.Message}");
        }
    }

    private bool IsOutOfBounds(Vector3 position)
    {
        float maxDistance = 100f;

        return Vector3.Distance(position, startPosition) > maxDistance;
    }

    private bool IsObstacleInPath(Vector3 targetPos, Vector3 direction)
    {
        try
        {
            Vector3 halfExtents = cachedTransform.localScale / 2f * 0.95f;

            Collider[] hits = Physics.OverlapBox(targetPos, halfExtents, cachedTransform.rotation, obstacleMask);

            foreach (Collider hit in hits)
            {
                if (hit.gameObject == gameObject)
                {
                    continue;
                }

                if (hit.CompareTag("Obstacle"))
                {
                    if (logMovementAttempts)
                    {
                        Debug.Log($"[MovableCube] Blocked by {hit.name}, cannot move {gameObject.name} in direction {direction}");
                    }
                    return true;
                }
            }

            return false;
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error checking for obstacles: {ex.Message}");
            return true;
        }
    }

    public void Highlight(bool on)
    {
        try
        {
            if (rend == null || rend.material == null) return;

            if (on)
            {
                Color highlightedColor = originalColor * 1.25f;

                highlightedColor.a = 1f;

                highlightedColor.r = Mathf.Clamp01(highlightedColor.r);
                highlightedColor.g = Mathf.Clamp01(highlightedColor.g);
                highlightedColor.b = Mathf.Clamp01(highlightedColor.b);

                rend.material.color = highlightedColor;
            }
            else
            {
                rend.material.color = originalColor;
            }
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error during highlight: {ex.Message}");
        }
    }

    public void ResetPosition()
    {
        try
        {
            cachedTransform.position = startPosition;
            Debug.Log($"[MovableCube] Reset {gameObject.name} to starting position");
        }
        catch (Exception ex)
        {
            Debug.LogError($"[MovableCube] Error resetting position: {ex.Message}");
        }
    }

    public string GetMovementStats()
    {
        float successRate = totalMoveAttempts > 0 ?
            (float)successfulMoves / totalMoveAttempts * 100f : 0f;

        return $"Movement success rate: {successRate:F1}% ({successfulMoves}/{totalMoveAttempts})";
    }
}

